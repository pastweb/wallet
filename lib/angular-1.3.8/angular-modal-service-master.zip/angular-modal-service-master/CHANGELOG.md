## v0.4

### Features

* The modal can now be added to any specific element in the DOM. If 
  unspecified, the modal is added to the `body`, as before.
  Thanks [cointilt](https://github.com/cointilt)!